--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.ruangan DROP CONSTRAINT ruangan_pkey;
ALTER TABLE ONLY public.petugas DROP CONSTRAINT petugas_pkey;
ALTER TABLE ONLY public.peminjaman DROP CONSTRAINT peminjaman_pkey;
ALTER TABLE ONLY public.pegawai DROP CONSTRAINT pegawai_pkey;
ALTER TABLE ONLY public.level DROP CONSTRAINT level_pkey;
ALTER TABLE ONLY public.jenis DROP CONSTRAINT jenis_pkey;
ALTER TABLE ONLY public.inventaris DROP CONSTRAINT inventaris_pkey;
ALTER TABLE ONLY public.detail_pinjam DROP CONSTRAINT detail_pinjam_pkey;
DROP TABLE public.ruangan;
DROP TABLE public.petugas;
DROP TABLE public.peminjaman;
DROP TABLE public.pegawai;
DROP TABLE public.level;
DROP TABLE public.jenis;
DROP TABLE public.inventaris;
DROP TABLE public.detail_pinjam;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: detail_pinjam; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE detail_pinjam (
    id_detail_pinjam character varying(100) NOT NULL,
    id_inventaris character varying(50) NOT NULL,
    jumlah integer NOT NULL,
    updated_at timestamp without time zone
);


ALTER TABLE detail_pinjam OWNER TO postgres;

--
-- Name: inventaris; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE inventaris (
    id_inventaris character varying(100) NOT NULL,
    nama character varying(50) NOT NULL,
    kondisi character varying(100) NOT NULL,
    keterangan character varying(100) NOT NULL,
    jumlah integer NOT NULL,
    id_jenis character varying(100) NOT NULL,
    tanggal_register date NOT NULL,
    id_ruang character varying(100) NOT NULL,
    kode_inventaris character varying(100) NOT NULL,
    id_petugas character varying(100) NOT NULL
);


ALTER TABLE inventaris OWNER TO postgres;

--
-- Name: jenis; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE jenis (
    id_jenis character varying(100) NOT NULL,
    nama_jenis character varying(50) NOT NULL,
    kode_jenis character varying(100) NOT NULL,
    keterangan character varying(100) NOT NULL,
    updated_at timestamp without time zone
);


ALTER TABLE jenis OWNER TO postgres;

--
-- Name: level; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE level (
    id_level character varying(100) NOT NULL,
    nama_level character varying(50) NOT NULL,
    updated_at timestamp without time zone
);


ALTER TABLE level OWNER TO postgres;

--
-- Name: pegawai; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE pegawai (
    id_pegawai character varying(100) NOT NULL,
    nama_pegawai character varying(50) NOT NULL,
    nip character varying(100) NOT NULL,
    alamat character varying(100) NOT NULL,
    updated_at timestamp without time zone
);


ALTER TABLE pegawai OWNER TO postgres;

--
-- Name: peminjaman; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE peminjaman (
    id_peminjaman character varying(20) NOT NULL,
    tanggal_pinjam date NOT NULL,
    tanggal_kembali date NOT NULL,
    status_peminjaman character varying(100) NOT NULL,
    id_pegawai character varying(100)
);


ALTER TABLE peminjaman OWNER TO postgres;

--
-- Name: petugas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE petugas (
    id_petugas character varying(20) NOT NULL,
    username character varying(50) NOT NULL,
    password character varying(100) NOT NULL,
    nama_petugas character varying(100) NOT NULL,
    id_level character varying(100) NOT NULL,
    updated_at timestamp without time zone
);


ALTER TABLE petugas OWNER TO postgres;

--
-- Name: ruangan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE ruangan (
    id_ruangan character varying(20) NOT NULL,
    nama_ruangan character varying(50) NOT NULL,
    kode_ruangan character varying(100) NOT NULL,
    keterangan character varying(100) NOT NULL,
    updated_at timestamp without time zone
);


ALTER TABLE ruangan OWNER TO postgres;

--
-- Data for Name: detail_pinjam; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY detail_pinjam (id_detail_pinjam, id_inventaris, jumlah, updated_at) FROM stdin;
\.
COPY detail_pinjam (id_detail_pinjam, id_inventaris, jumlah, updated_at) FROM '$$PATH$$/2840.dat';

--
-- Data for Name: inventaris; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY inventaris (id_inventaris, nama, kondisi, keterangan, jumlah, id_jenis, tanggal_register, id_ruang, kode_inventaris, id_petugas) FROM stdin;
\.
COPY inventaris (id_inventaris, nama, kondisi, keterangan, jumlah, id_jenis, tanggal_register, id_ruang, kode_inventaris, id_petugas) FROM '$$PATH$$/2841.dat';

--
-- Data for Name: jenis; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY jenis (id_jenis, nama_jenis, kode_jenis, keterangan, updated_at) FROM stdin;
\.
COPY jenis (id_jenis, nama_jenis, kode_jenis, keterangan, updated_at) FROM '$$PATH$$/2834.dat';

--
-- Data for Name: level; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY level (id_level, nama_level, updated_at) FROM stdin;
\.
COPY level (id_level, nama_level, updated_at) FROM '$$PATH$$/2837.dat';

--
-- Data for Name: pegawai; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY pegawai (id_pegawai, nama_pegawai, nip, alamat, updated_at) FROM stdin;
\.
COPY pegawai (id_pegawai, nama_pegawai, nip, alamat, updated_at) FROM '$$PATH$$/2838.dat';

--
-- Data for Name: peminjaman; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY peminjaman (id_peminjaman, tanggal_pinjam, tanggal_kembali, status_peminjaman, id_pegawai) FROM stdin;
\.
COPY peminjaman (id_peminjaman, tanggal_pinjam, tanggal_kembali, status_peminjaman, id_pegawai) FROM '$$PATH$$/2839.dat';

--
-- Data for Name: petugas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY petugas (id_petugas, username, password, nama_petugas, id_level, updated_at) FROM stdin;
\.
COPY petugas (id_petugas, username, password, nama_petugas, id_level, updated_at) FROM '$$PATH$$/2836.dat';

--
-- Data for Name: ruangan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ruangan (id_ruangan, nama_ruangan, kode_ruangan, keterangan, updated_at) FROM stdin;
\.
COPY ruangan (id_ruangan, nama_ruangan, kode_ruangan, keterangan, updated_at) FROM '$$PATH$$/2835.dat';

--
-- Name: detail_pinjam detail_pinjam_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY detail_pinjam
    ADD CONSTRAINT detail_pinjam_pkey PRIMARY KEY (id_detail_pinjam);


--
-- Name: inventaris inventaris_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY inventaris
    ADD CONSTRAINT inventaris_pkey PRIMARY KEY (id_inventaris);


--
-- Name: jenis jenis_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY jenis
    ADD CONSTRAINT jenis_pkey PRIMARY KEY (id_jenis);


--
-- Name: level level_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY level
    ADD CONSTRAINT level_pkey PRIMARY KEY (id_level);


--
-- Name: pegawai pegawai_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pegawai
    ADD CONSTRAINT pegawai_pkey PRIMARY KEY (id_pegawai);


--
-- Name: peminjaman peminjaman_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY peminjaman
    ADD CONSTRAINT peminjaman_pkey PRIMARY KEY (id_peminjaman);


--
-- Name: petugas petugas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY petugas
    ADD CONSTRAINT petugas_pkey PRIMARY KEY (id_petugas);


--
-- Name: ruangan ruangan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ruangan
    ADD CONSTRAINT ruangan_pkey PRIMARY KEY (id_ruangan);


--
-- PostgreSQL database dump complete
--

